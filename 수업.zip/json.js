
const request = require('request');
const cheerio = require('cheerio');

const url = 'https://newsstand.naver.com/?list=&pcode=022';
request(url, (error, response, body) => {
    const $ = cheerio.load(body);


    $('.lst_news').each((index, element) => {
        //const title = $(element).find('.book_tit').text().trim();
        let writer = $(element).find('.blind').text().trim();
        //writer = writer.split(',').map((item) => item.trim());

        console.log(writer);
    })
})