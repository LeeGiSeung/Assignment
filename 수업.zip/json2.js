const { response } = require('express');
const request = require('request');

const url = 'https://newsstand.naver.com/?list=&pcode=022';
request(url, (error, response, body) => {
    console.log(body);
})