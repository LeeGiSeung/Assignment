/*
const request = require('request');
const cheerio = require('cheerio');
const { response } = require('express');

const url = 'http://www.hanbit.co.kr/store/books/new_book_list.html';
request(url, (error, response, body) => {
    const $ = cheerio.load(body);

    $('.view_box').each((index, element) => {
        const title = $(element).find('.book.tit').text().trim();
        let writer = $(element).find('.book_writer').text().trim();
        writer = writer.split(',').map((item) => item.trim());

        console.log(title);
        console.log(writer);
        console.log();
    })
})*/