const request = require('request');
const cheerio = require('cheerio');

const url = "https://www.uhs.ac.kr/uhs/75/subview.do";
request(url, (error, response, body) => {
    const $ = cheerio.load(body);

    $('._contentBuilder').each((index, element) => {
        const header1 = $(element).find('.objHeading_h3').text();
        const list = $(element).find('.con-list').text();
        const header2 = $(element).find('.objHeading_h4').text();
        const header2_2 = $(element).find('#menu75_obj98').text();
        const header2_1 = $(element).find('#menu75_obj104').text();

        //console.log("header1 : "+header1);
   
        console.log(header2_1);
        console.log(header2_2);
        console.log("header2 : "+header2);
        console.log("list : "+list);

    })

})
