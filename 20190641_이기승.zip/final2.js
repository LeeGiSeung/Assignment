
const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.listen(8981, () => {
    console.log('Server Running at http://127.0.0.1:8981');
});

app.use(bodyParser.urlencoded({
    extended: false
}));

let userCounter = 0;
const users = [];

app.get('/gets', (request, response) => {
    response.send(users);
});

app.post('/posts', (request, response) => {
    const body = request.body;

    if(!body.itemName){
        return response.status(400).send('name을 보내주세요');
    }
    else if(!body.orderCount){
        return response.status(400).send('count을 보내주세요.');
    }

    else if(!body.orderDate){
        return response.status(400).send('date을 보내주세요.');
    }

    else if(!body.itemId){
        return response.status(400).send('id을 보내주세요.');
    }

    const itemName = body.itemName;
    const orderCount = body.orderCount;
    const orderDate = body.orderDate;
    const itemId = body.itemId;

    const data = {
        itemId:itemId,
        itemName: itemName,
        orderCount: orderCount,
        orderDate: orderDate
    };
    users.push(data);

    response.send(data);
});

app.get('/gets/:parameter', (request, response) => {
    const parameter = request.params.parameter;

    const filtered = users.filter((user) => user.parameter == id);

    if(filtered.length == 1){
        response.send(filtered[0]);
    }
    else{
        response.status(404).send('데이터가 존재하지 않습니다.');
    }
});

app.put('/puts/:parameter', (request, response) => {
    const parameter = request.params.parameter;
    let isExist = false;

    users.forEach((user) => {
        if(user.parameter == parameter)
        
        isExist = true;
        if(request.body.name){
            users[parameter].name = request.body.name;
        }
        if(request.body.count){
            users[parameter].count = request.body.count;
        }
        if(request.body.date){
            users[parameter].date = request.body.date;
        }

        if(request.body.date){
            users[parameter].date = request.body.date;
        }
        response.send(parameter);
    })
});

app.delete('/dels/:parameter', (request, response) => {
    const parameter = request.params.parameter;
    let deletedUser = null;

    for(let i = users.length -1; i>= 0; i--){
        if(users[i].parameter == parameter) {
            deletedUser = users[i];
            users.splice(i, 1); 

            break;
       }
    }

    if(deletedUser){
        response.send(deletedUser);
    }
    else{
        response.status(404).send('데이터가 존재하지 않습니다.');
    }
});